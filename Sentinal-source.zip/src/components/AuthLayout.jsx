import React from "react";

export default function AuthLayout({ icon: Icon, title, subtitle, footer, children }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-mesh-purple px-4 py-8 relative overflow-hidden">
      {/* Ambient floating orbs */}
      <div className="absolute top-10 left-10 w-40 h-40 rounded-full bg-purple-600/20 blur-3xl animate-float" />
      <div className="absolute bottom-10 right-10 w-52 h-52 rounded-full bg-indigo-600/15 blur-3xl animate-float" style={{ animationDelay: '1s' }} />
      <div className="absolute top-1/2 left-1/3 w-32 h-32 rounded-full bg-fuchsia-600/10 blur-3xl animate-float" style={{ animationDelay: '2s' }} />

      <div className="w-full max-w-md relative z-10">
        {/* Logo + Tagline */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center mb-3">
            <div className="relative">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-mint to-holo animate-orb" />
              <div className="absolute inset-0 w-12 h-12 rounded-full border border-mint/30 animate-spin-slow" />
            </div>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            Sent<span className="text-gradient-mint">inal</span>
          </h1>
          <p className="text-sm text-white/40 mt-1 font-medium tracking-wide">Learn it. Scan it. Build it.</p>
        </div>

        {/* Glass card */}
        <div className="glass-strong rounded-3xl p-8 shadow-2xl">
          <div className="mb-6">
            <div className="flex items-center gap-3 mb-2">
              {Icon && (
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-xl bg-mint/10 border border-mint/20">
                  <Icon className="w-5 h-5 text-mint" aria-hidden="true" />
                </div>
              )}
              <h2 className="text-xl font-bold text-white">{title}</h2>
            </div>
            {subtitle && <p className="text-sm text-white/40 ml-13">{subtitle}</p>}
          </div>
          {children}
        </div>

        {footer && (
          <p className="text-center text-sm text-white/30 mt-6">{footer}</p>
        )}
      </div>
    </div>
  );
}