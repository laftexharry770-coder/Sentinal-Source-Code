import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Home, GraduationCap, User } from "lucide-react";
import SenOrb from "@/components/SenOrb";

export default function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = [
    { icon: Home, label: "Home", path: "/" },
    { icon: GraduationCap, label: "Learn", path: "/learn" },
    null,
    { icon: User, label: "Profile", path: "/profile" },
  ];

  const isActive = (path) => {
    if (path === "/") return location.pathname === "/";
    return location.pathname.startsWith(path);
  };

  return (
    <div className="fixed bottom-0 inset-x-0 z-40 pointer-events-none" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      <div className="glass-strong border-t border-white/5 pointer-events-auto">
        <div className="flex items-center justify-around max-w-lg mx-auto px-4 h-16 relative">
          {navItems.map((item, i) => {
            if (item === null) return <SenOrb key="sen" />;

            const active = isActive(item.path);
            const Icon = item.icon;
            return (
              <button
                key={i}
                onClick={() => navigate(item.path)}
                className="flex flex-col items-center gap-1 px-4 py-2 transition-all"
              >
                <Icon
                  className={`w-5 h-5 transition-all ${active ? "text-mint" : "text-white/40"}`}
                  strokeWidth={active ? 2.5 : 2}
                />
                <span className={`text-[10px] font-medium transition-all ${active ? "text-mint" : "text-white/30"}`}>
                  {item.label}
                </span>
                {active && <div className="absolute bottom-1 w-1 h-1 rounded-full bg-mint" />}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}