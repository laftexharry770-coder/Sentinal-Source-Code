import React from "react";
import { Link } from "react-router-dom";
import { Lock, ChevronRight, Clock, Star, Cog, Fuel, Zap, Settings, Waves, Disc, Thermometer, Wind, Car, Snowflake, Battery } from "lucide-react";
import { CATEGORY_COLORS } from "@/lib/courseData";

const ICON_MAP = { Cog, Fuel, Zap, Settings, Waves, Disc, Thermometer, Wind, Car, Snowflake, Battery };

export default function CourseCard({ course, index }) {
  const color = CATEGORY_COLORS[course.category] || "#2DD4BF";
  const Icon = ICON_MAP[course.icon] || Cog;

  return (
    <div className="relative flex items-center gap-4 pl-0">
      {/* Timeline dot / icon */}
      <div className="relative z-10 flex-shrink-0">
        <div
          className={`w-14 h-14 rounded-full flex items-center justify-center border-2 transition-all ${
            course.locked ? "bg-card border-white/5" : "glass-card"
          }`}
          style={{ borderColor: course.locked ? undefined : `${color}30` }}
        >
          {course.locked ? (
            <Lock className="w-5 h-5 text-white/20" />
          ) : (
            <Icon className="w-6 h-6" style={{ color }} />
          )}
        </div>
      </div>

      {/* Card */}
      <Link
        to={course.locked ? "#" : `/course/${course.id}`}
        className={`flex-1 glass-card rounded-2xl p-4 transition-all ${
          course.locked ? "opacity-50 cursor-not-allowed" : "hover:border-white/15 cursor-pointer"
        }`}
        onClick={course.locked ? (e) => e.preventDefault() : undefined}
      >
        <div className="flex items-start justify-between gap-3 mb-1">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-full" style={{ backgroundColor: `${color}15`, color }}>
                {course.category}
              </span>
              {course.locked && (
                <span className="text-[10px] text-white/30 font-medium">Coming soon</span>
              )}
            </div>
            <h3 className="text-white font-bold text-sm leading-tight mb-1">{course.title}</h3>
            <p className="text-white/40 text-xs leading-snug line-clamp-2">{course.description}</p>
          </div>
          {!course.locked && (
            <ChevronRight className="w-4 h-4 text-white/20 flex-shrink-0 mt-1" />
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center gap-3 mt-2">
          <div className="flex items-center gap-1 text-white/30 text-[11px]">
            <Clock className="w-3 h-3" />
            {course.duration}
          </div>
          <div className="flex items-center gap-1 text-white/30 text-[11px]">
            <Star className="w-3 h-3" />
            {course.xpTotal} XP
          </div>
          {!course.locked && course.steps && (
            <div className="flex items-center gap-1 text-white/30 text-[11px]">
              {course.steps.length} steps
            </div>
          )}
        </div>
      </Link>
    </div>
  );
}