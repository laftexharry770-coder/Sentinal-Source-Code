import React, { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ENGINE_PARTS } from "@/lib/courseData";

const PHASE_NAMES = ["Intake", "Compression", "Power", "Exhaust"];
const PHASE_COLORS = ["#00D4FF", "#A78BFA", "#F59E0B", "#FB923C"];

// Engine geometry constants
const CENTER_X = 180;
const CRANK_Y = 350;
const CRANK_R = 38;
const ROD_LEN = 135;
const PISTON_H = 36;
const PISTON_W = 64;
const PISTON_X = CENTER_X - PISTON_W / 2;
const CYL_TOP = 85;
const CYL_BOT = 300;

export default function EngineVisualization({
  phase = null,
  paused = false,
  interactive = false,
  exploded = false,
  showLabels = false,
  highlightedPart = null,
  onPartClick,
}) {
  const [angle, setAngle] = useState(0);
  const rafRef = useRef();
  const lastTimeRef = useRef(0);

  useEffect(() => {
    if (paused) {
      const phaseAngle = phase !== null ? phase * 180 + 90 : 90;
      setAngle(phaseAngle);
      return;
    }

    let startAngle = phase !== null ? phase * 180 : 0;
    setAngle(startAngle);

    const animate = (time) => {
      if (lastTimeRef.current) {
        const delta = time - lastTimeRef.current;
        const speed = 0.06;
        setAngle(prev => {
          let next = prev + delta * speed;
          if (phase !== null) {
            const min = phase * 180;
            const max = min + 180;
            if (next >= max) next = min;
          } else {
            if (next >= 720) next = 0;
          }
          return next;
        });
      }
      lastTimeRef.current = time;
      rafRef.current = requestAnimationFrame(animate);
    };
    rafRef.current = requestAnimationFrame(animate);
    return () => {
      cancelAnimationFrame(rafRef.current);
      lastTimeRef.current = 0;
    };
  }, [paused, phase]);

  // Derived values
  const rad = angle * Math.PI / 180;
  const crankPinX = CENTER_X + CRANK_R * Math.sin(rad);
  const crankPinY = CRANK_Y - CRANK_R * Math.cos(rad);
  const rodDx = crankPinX - CENTER_X;
  const pistonBottomY = crankPinY - Math.sqrt(Math.max(0, ROD_LEN * ROD_LEN - rodDx * rodDx));
  const pistonTopY = pistonBottomY - PISTON_H;

  // Current phase (0-3) based on angle
  const currentPhase = Math.floor(angle / 180) % 4;

  // Valve states
  const intakeOpen = angle < 180;
  const exhaustOpen = angle >= 540;
  const sparkFiring = angle >= 350 && angle <= 380;

  // Exploded offsets
  const ex = exploded ? 1 : 0;
  const explode = (part) => {
    const offsets = {
      cylinder_head: { x: 0, y: -70 * ex },
      spark_plug: { x: 0, y: -110 * ex },
      intake_valve: { x: -35 * ex, y: -60 * ex },
      exhaust_valve: { x: 35 * ex, y: -60 * ex },
      piston: { x: 55 * ex, y: 0 },
      connecting_rod: { x: 55 * ex, y: 40 * ex },
      crankshaft: { x: 0, y: 70 * ex },
    };
    return offsets[part] || { x: 0, y: 0 };
  };

  const partProps = useCallback((partId) => ({
    onClick: interactive ? () => onPartClick?.(partId) : undefined,
    style: { cursor: interactive ? "pointer" : "default" },
    opacity: highlightedPart && highlightedPart !== partId ? 0.3 : 1,
    transition: "opacity 0.3s",
  }), [interactive, highlightedPart, onPartClick]);

  const stroke = (partId, base = "rgba(0, 212, 255, 0.7)") =>
    highlightedPart === partId ? "#2DD4BF" : base;

  return (
    <div className="relative w-full aspect-square max-w-md mx-auto">
      <svg viewBox="0 0 360 440" className="w-full h-full" style={{ filter: "drop-shadow(0 0 12px rgba(0, 212, 255, 0.15))" }}>
        <defs>
          <filter id="engine-glow">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <filter id="spark-glow">
            <feGaussianBlur stdDeviation="6" result="blur" />
            <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <linearGradient id="piston-grad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="rgba(0, 212, 255, 0.15)" />
            <stop offset="100%" stopColor="rgba(0, 212, 255, 0.05)" />
          </linearGradient>
          <radialGradient id="spark-grad">
            <stop offset="0%" stopColor="rgba(255, 200, 50, 0.9)" />
            <stop offset="50%" stopColor="rgba(245, 158, 11, 0.6)" />
            <stop offset="100%" stopColor="rgba(245, 158, 11, 0)" />
          </radialGradient>
        </defs>

        {/* Phase indicator ring */}
        <circle cx={CENTER_X} cy={CRANK_Y} r={CRANK_R + 18} fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="1" strokeDasharray="3 3" />

        {/* Engine block */}
        <g style={{ transition: "transform 0.6s ease" }}>
          <rect x="100" y="50" width="160" height="300" rx="10" fill="rgba(0,212,255,0.02)" stroke="rgba(0,212,255,0.15)" strokeWidth="1.5" />

          {/* Cylinder head */}
          <g style={{ transform: `translate(${explode("cylinder_head").x}px, ${explode("cylinder_head").y}px)`, transition: "transform 0.6s ease" }} {...partProps("cylinder_head")}>
            <rect x="90" y="40" width="180" height="35" rx="6" fill="rgba(0,212,255,0.04)" stroke={stroke("cylinder_head", "rgba(0,212,255,0.3)")} strokeWidth="1.5" />
            {showLabels && <text x={CENTER_X} y="28" textAnchor="middle" fill="rgba(0,212,255,0.6)" fontSize="9" className="font-mono">Cylinder Head</text>}
          </g>

          {/* Cylinder bore */}
          <rect x={CENTER_X - 34} y={CYL_TOP} width="68" height={CYL_BOT - CYL_TOP} rx="4" fill="rgba(0,212,255,0.015)" stroke="rgba(0,212,255,0.12)" strokeWidth="1" strokeDasharray="4 4" />
        </g>

        {/* Spark Plug */}
        <g style={{ transform: `translate(${explode("spark_plug").x}px, ${explode("spark_plug").y}px)`, transition: "transform 0.6s ease" }} {...partProps("spark_plug")}>
          <line x1={CENTER_X} y1="20" x2={CENTER_X} y2={CYL_TOP} stroke={stroke("spark_plug")} strokeWidth="2.5" filter="url(#engine-glow)" />
          <rect x={CENTER_X - 8} y="14" width="16" height="12" rx="2" fill="rgba(0,212,255,0.1)" stroke={stroke("spark_plug")} strokeWidth="1.5" />
          {showLabels && <text x={CENTER_X} y="8" textAnchor="middle" fill={stroke("spark_plug")} fontSize="9" className="font-mono">Spark Plug</text>}
          {sparkFiring && !exploded && (
            <>
              <circle cx={CENTER_X} cy={CYL_TOP + 5} r="14" fill="url(#spark-grad)" filter="url(#spark-glow)" />
              <circle cx={CENTER_X} cy={CYL_TOP + 5} r="5" fill="rgba(255, 220, 100, 0.9)" filter="url(#spark-glow)" />
            </>
          )}
        </g>

        {/* Intake Valve */}
        <g style={{ transform: `translate(${explode("intake_valve").x}px, ${explode("intake_valve").y + (intakeOpen && !exploded ? 10 : 0)}px)`, transition: "transform 0.6s ease" }} {...partProps("intake_valve")}>
          <line x1="150" y1="60" x2="150" y2="78" stroke={stroke("intake_valve")} strokeWidth="2.5" filter="url(#engine-glow)" />
          <ellipse cx="150" cy="82" rx="11" ry="4" fill={intakeOpen && !exploded ? "rgba(0,212,255,0.2)" : "rgba(0,212,255,0.08)"} stroke={stroke("intake_valve")} strokeWidth="1.5" />
          {showLabels && <text x="118" y="82" textAnchor="end" fill={stroke("intake_valve")} fontSize="9" className="font-mono">Intake</text>}
          {intakeOpen && !exploded && (
            <g opacity="0.6">
              <circle cx="155" cy="100" r="2" fill="#00D4FF" />
              <circle cx="148" cy="115" r="1.5" fill="#00D4FF" />
              <circle cx="160" cy="130" r="2" fill="#00D4FF" />
            </g>
          )}
        </g>

        {/* Exhaust Valve */}
        <g style={{ transform: `translate(${explode("exhaust_valve").x}px, ${explode("exhaust_valve").y + (exhaustOpen && !exploded ? 10 : 0)}px)`, transition: "transform 0.6s ease" }} {...partProps("exhaust_valve")}>
          <line x1="210" y1="60" x2="210" y2="78" stroke={stroke("exhaust_valve")} strokeWidth="2.5" filter="url(#engine-glow)" />
          <ellipse cx="210" cy="82" rx="11" ry="4" fill={exhaustOpen && !exploded ? "rgba(251,146,60,0.2)" : "rgba(0,212,255,0.08)"} stroke={stroke("exhaust_valve")} strokeWidth="1.5" />
          {showLabels && <text x="242" y="82" textAnchor="start" fill={stroke("exhaust_valve")} fontSize="9" className="font-mono">Exhaust</text>}
          {exhaustOpen && !exploded && (
            <g opacity="0.5">
              <circle cx="205" cy="100" r="2" fill="#FB923C" />
              <circle cx="212" cy="80" r="1.5" fill="#FB923C" />
            </g>
          )}
        </g>

        {/* Piston */}
        <g style={{ transform: `translate(${explode("piston").x}px, 0)`, transition: "transform 0.6s ease" }} {...partProps("piston")}>
          <g style={{ transform: `translateY(${pistonTopY}px)`, transition: paused ? "transform 0.5s ease" : "none" }}>
            <rect x={PISTON_X} y="0" width={PISTON_W} height={PISTON_H} rx="4" fill="url(#piston-grad)" stroke={stroke("piston")} strokeWidth="1.5" filter="url(#engine-glow)" />
            <line x1={CENTER_X} y1={PISTON_H} x2={crankPinX - explode("piston").x} y2={crankPinY - pistonTopY} stroke={stroke("connecting_rod", "rgba(0,212,255,0.5)")} strokeWidth="3" filter="url(#engine-glow)" />
            {showLabels && <text x={PISTON_X + PISTON_W + 8} y={PISTON_H / 2} fill={stroke("piston")} fontSize="9" className="font-mono">Piston</text>}
          </g>
        </g>

        {/* Crankshaft */}
        <g style={{ transform: `translate(${explode("crankshaft").x}px, ${explode("crankshaft").y}px)`, transition: "transform 0.6s ease" }} {...partProps("crankshaft")}>
          <circle cx={CENTER_X} cy={CRANK_Y} r={CRANK_R + 8} fill="none" stroke="rgba(0,212,255,0.08)" strokeWidth="1" strokeDasharray="2 4" />
          <circle cx={CENTER_X} cy={CRANK_Y} r="7" fill="rgba(0,212,255,0.2)" stroke={stroke("crankshaft")} strokeWidth="1.5" />
          <line x1={CENTER_X} y1={CRANK_Y} x2={crankPinX - explode("crankshaft").x} y2={crankPinY - explode("crankshaft").y} stroke={stroke("crankshaft", "rgba(0,212,255,0.6)")} strokeWidth="4" filter="url(#engine-glow)" />
          <circle cx={crankPinX - explode("crankshaft").x} cy={crankPinY - explode("crankshaft").y} r="5" fill="rgba(0,212,255,0.4)" stroke={stroke("crankshaft")} strokeWidth="1.5" />
          {showLabels && <text x={CENTER_X} y={CRANK_Y + 55} textAnchor="middle" fill={stroke("crankshaft")} fontSize="9" className="font-mono">Crankshaft</text>}
        </g>

        {/* Phase label */}
        {!exploded && !showLabels && (
          <text x={CENTER_X} y="425" textAnchor="middle" fill={PHASE_COLORS[currentPhase]} fontSize="13" fontWeight="600" className="font-heading">
            {PHASE_NAMES[currentPhase]} Stroke
          </text>
        )}
      </svg>

      {/* Phase indicator dots */}
      {!showLabels && !exploded && (
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 flex gap-2 mb-1">
          {[0, 1, 2, 3].map(p => (
            <div
              key={p}
              className="w-1.5 h-1.5 rounded-full transition-all"
              style={{
                backgroundColor: p === currentPhase ? PHASE_COLORS[p] : "rgba(255,255,255,0.15)",
                transform: p === currentPhase ? "scale(1.5)" : "scale(1)",
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}