import React, { useEffect } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import BottomNav from "@/components/BottomNav";
import { useAuth } from "@/lib/AuthContext";

export default function Layout() {
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user && !user.tutorial_completed) {
      navigate("/tutorial");
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen bg-background bg-mesh" style={{ paddingTop: "env(safe-area-inset-top)" }}>
      <main className="pb-28 max-w-5xl mx-auto">
        <Outlet />
      </main>
      <BottomNav />
    </div>
  );
}