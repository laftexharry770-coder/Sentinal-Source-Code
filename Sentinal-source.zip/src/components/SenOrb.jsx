import React, { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { X, Mic, MicOff, Volume2, VolumeX, Send, Sparkles, Loader2 } from "lucide-react";
import { SEN_SYSTEM_PROMPT, detectNavigation, askGemini } from "@/lib/senConfig";
import { useAuth } from "@/lib/AuthContext";
import { speak, stopSpeaking, getSpeechRecognition, isSpeechRecognitionSupported, isSpeechSynthesisSupported } from "@/lib/speech";

const SUGGESTIONS = [
  "How does a four-stroke engine work?",
  "Explain fuel injection",
  "Open Learn",
  "Start the Four-Stroke course",
  "What's a catalytic converter?",
  "Go to my profile",
];

export default function SenOrb() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [muted, setMuted] = useState(false);
  const [recognition, setRecognition] = useState(null);
  const messagesEndRef = useRef(null);
  const transcriptRef = useRef("");
  const handleSendRef = useRef(null);

  // Load chat history
  useEffect(() => {
    loadMessages();
  }, []);

  // Listen for external open events
  useEffect(() => {
    const handler = () => setOpen(true);
    window.addEventListener("open-sen-chat", handler);
    return () => window.removeEventListener("open-sen-chat", handler);
  }, []);

  // Init speech recognition
  useEffect(() => {
    const rec = getSpeechRecognition();
    if (rec) {
      rec.onresult = (e) => {
        const transcript = Array.from(e.results)
          .map(r => r[0].transcript)
          .join("");
        transcriptRef.current = transcript;
        setInput(transcript);
      };
      rec.onend = () => {
        setListening(false);
        const finalText = transcriptRef.current.trim();
        transcriptRef.current = "";
        if (finalText && handleSendRef.current) handleSendRef.current(finalText);
      };
      rec.onerror = () => setListening(false);
      setRecognition(rec);
    }
  }, []);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // Stop speaking when closing
  useEffect(() => {
    if (!open) {
      stopSpeaking();
      setSpeaking(false);
    }
  }, [open]);

  const loadMessages = async () => {
    try {
      const history = await base44.entities.ChatMessage.list("-created_date", 50);
      setMessages(history.reverse());
    } catch {
      // empty state is fine
    }
  };

  const toggleMic = () => {
    if (!recognition) return;
    if (listening) {
      recognition.stop();
      setListening(false);
    } else {
      setInput("");
      transcriptRef.current = "";
      recognition.start();
      setListening(true);
    }
  };

  const handleSend = useCallback(async (text) => {
    const messageText = text || input.trim();
    if (!messageText || loading) return;

    setInput("");
    setLoading(true);

    // Detect navigation
    const navPath = detectNavigation(messageText);
    if (navPath) {
      setTimeout(() => navigate(navPath), 500);
    }

    // Add user message
    const userMsg = { content: messageText, role: "user" };
    setMessages(prev => [...prev, userMsg]);
    try {
      await base44.entities.ChatMessage.create(userMsg);
    } catch { /* non-critical */ }

    // Build conversation context
    const recentHistory = messages.slice(-8).map(m =>
      `${m.role === "user" ? "User" : "Sen"}: ${m.content}`
    ).join("\n");

    try {
      const fullPrompt = `${SEN_SYSTEM_PROMPT}\n\nConversation so far:\n${recentHistory}\n\nUser: ${messageText}\nSen:`;

      // Prefer the user's own Gemini key when saved on their profile;
      // fall back to the built-in LLM on any failure.
      let response = null;
      if (user?.gemini_api_key) {
        try {
          response = await askGemini(user.gemini_api_key, fullPrompt);
        } catch { /* fall through to built-in LLM */ }
      }

      if (!response) {
        const result = await base44.integrations.Core.InvokeLLM({ prompt: fullPrompt });
        response = typeof result === "string" ? result : (result?.response || result?.text || result?.output || "I'm here and ready to help. What would you like to learn?");
      }

      const assistantMsg = { content: response, role: "assistant" };
      setMessages(prev => [...prev, assistantMsg]);
      try {
        await base44.entities.ChatMessage.create(assistantMsg);
      } catch { /* non-critical */ }

      if (!muted && isSpeechSynthesisSupported()) {
        setSpeaking(true);
        speak(response, {
          onEnd: () => setSpeaking(false),
          onStart: () => setSpeaking(true),
        });
      }
    } catch (err) {
      const errorMsg = { content: "I'm having trouble connecting right now. Please try again in a moment.", role: "assistant" };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  }, [input, loading, messages, muted, navigate, recognition, user]);

  // Keep latest handleSend available to speech callbacks
  useEffect(() => { handleSendRef.current = handleSend; }, [handleSend]);

  const toggleMute = () => {
    if (!muted) {
      stopSpeaking();
      setSpeaking(false);
    }
    setMuted(!muted);
  };

  return (
    <>
      {/* Floating Orb Button */}
      <div className="pointer-events-auto">
        <button
          onClick={() => setOpen(true)}
          className="relative -mt-8 w-14 h-14 rounded-full bg-gradient-to-br from-mint to-holo animate-orb flex items-center justify-center"
          aria-label="Open Sen chat"
        >
          <Sparkles className="w-6 h-6 text-background" />
        </button>
      </div>

      {/* Chat Panel */}
      <AnimatePresence>
        {open && (
          <>
            {/* Backdrop on mobile */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 bg-black/60 z-50 md:hidden"
            />

            <motion.div
              initial={{ y: "100%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0 }}
              transition={{ type: "spring", damping: 28, stiffness: 300 }}
              className="fixed z-50 inset-x-0 bottom-0 md:inset-x-auto md:right-4 md:bottom-4 md:w-[400px] glass-strong rounded-t-3xl md:rounded-3xl border border-white/10 overflow-hidden flex flex-col"
              style={{ maxHeight: "85vh", height: "85vh" }}
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-white/5">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className={`w-9 h-9 rounded-full bg-gradient-to-br from-mint to-holo ${speaking ? "animate-orb" : ""}`} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white text-sm">Sen</h3>
                    <p className="text-[10px] text-mint flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-mint animate-pulse" />
                      {speaking ? "Speaking..." : listening ? "Listening..." : "Online"}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={toggleMute} className="p-2 rounded-lg hover:bg-white/5 text-white/40 hover:text-white/80 transition-all" aria-label="Toggle mute">
                    {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <button onClick={() => setOpen(false)} className="p-2 rounded-lg hover:bg-white/5 text-white/40 hover:text-white/80 transition-all" aria-label="Close chat">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-none">
                {messages.length === 0 && !loading && (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-mint to-holo animate-orb mx-auto mb-4 flex items-center justify-center">
                      <Sparkles className="w-7 h-7 text-background" />
                    </div>
                    <p className="text-white/60 text-sm font-medium">Hi, I'm Sen</p>
                    <p className="text-white/30 text-xs mt-1">Your AI mechanics teacher. Ask me anything.</p>
                  </div>
                )}

                {messages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[80%] px-4 py-2.5 text-sm ${
                        msg.role === "user"
                          ? "bg-gradient-to-br from-mint/80 to-holo/80 text-background rounded-2xl rounded-br-md font-medium"
                          : "glass text-white/90 rounded-2xl rounded-bl-md"
                      }`}
                    >
                      {msg.content}
                    </div>
                  </div>
                ))}

                {loading && (
                  <div className="flex justify-start">
                    <div className="glass px-4 py-3 rounded-2xl rounded-bl-md flex items-center gap-2">
                      <div className="flex gap-1">
                        <div className="w-2 h-2 rounded-full bg-mint/60 animate-pulse" style={{ animationDelay: '0s' }} />
                        <div className="w-2 h-2 rounded-full bg-mint/60 animate-pulse" style={{ animationDelay: '0.2s' }} />
                        <div className="w-2 h-2 rounded-full bg-mint/60 animate-pulse" style={{ animationDelay: '0.4s' }} />
                      </div>
                    </div>
                  </div>
                )}

                {/* Suggestions */}
                {messages.length === 0 && !loading && (
                  <div className="flex flex-wrap gap-2 mt-4">
                    {SUGGESTIONS.map((s, i) => (
                      <button
                        key={i}
                        onClick={() => handleSend(s)}
                        className="px-3 py-1.5 text-xs rounded-full glass text-white/60 hover:text-white hover:border-mint/30 transition-all"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="p-3 border-t border-white/5">
                <div className="flex items-center gap-2">
                  <button
                    onClick={toggleMic}
                    disabled={!recognition}
                    className={`p-2.5 rounded-xl transition-all flex-shrink-0 ${
                      listening
                        ? "bg-red-500/20 text-red-400 animate-pulse"
                        : recognition
                        ? "glass text-mint hover:bg-mint/10"
                        : "glass text-white/20"
                    }`}
                    aria-label="Voice input"
                  >
                    {listening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>
                  <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSend()}
                    placeholder={listening ? "Listening..." : "Ask Sen anything..."}
                    className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/20 outline-none focus:border-mint/30"
                  />
                  <button
                    onClick={() => handleSend()}
                    disabled={!input.trim() || loading}
                    className="p-2.5 rounded-xl bg-gradient-to-br from-mint to-holo text-background disabled:opacity-30 transition-all flex-shrink-0"
                    aria-label="Send"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}