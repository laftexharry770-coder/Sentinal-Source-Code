import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, ChevronRight, Volume2, VolumeX } from "lucide-react";
import { PHASE_NARRATIONS } from "@/lib/courseData";
import { speak, stopSpeaking, isSpeechSynthesisSupported } from "@/lib/speech";

export default function AnimatedExplanation({ setEngineConfig, onComplete }) {
  const [phase, setPhase] = useState(0);
  const [muted, setMuted] = useState(false);

  const current = PHASE_NARRATIONS[phase];

  // Configure engine for current phase
  useEffect(() => {
    setEngineConfig({
      phase: phase,
      paused: false,
      interactive: false,
      exploded: false,
      showLabels: false,
      highlightedPart: null,
    });
  }, [phase, setEngineConfig]);

  // Speak narration on phase change
  useEffect(() => {
    if (muted || !isSpeechSynthesisSupported()) return;
    speak(current.narration);
    return () => stopSpeaking();
  }, [phase, muted]);

  const handleNext = () => {
    stopSpeaking();
    if (phase < PHASE_NARRATIONS.length - 1) {
      setPhase(p => p + 1);
    } else {
      onComplete();
    }
  };

  const toggleMute = () => {
    if (!muted) stopSpeaking();
    setMuted(!muted);
  };

  return (
    <div>
      {/* Phase indicator */}
      <div className="flex items-center gap-2 mb-4">
        {PHASE_NARRATIONS.map((p, i) => (
          <div
            key={i}
            className="flex-1 h-1 rounded-full transition-all"
            style={{ backgroundColor: i <= phase ? p.color : "rgba(255,255,255,0.08)" }}
          />
        ))}
      </div>

      {/* Sen avatar + narration */}
      <div className="flex items-start gap-3 mb-4">
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-mint to-holo flex-shrink-0 flex items-center justify-center animate-orb">
          <Sparkles className="w-4 h-4 text-background" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-mint text-xs font-semibold">Sen</span>
            <span className="text-white/20 text-xs">·</span>
            <span className="text-white/40 text-xs">narrating</span>
          </div>
          <AnimatePresence mode="wait">
            <motion.div
              key={phase}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="text-white font-bold text-lg mb-2" style={{ color: current.color }}>
                {current.name} Stroke
              </h3>
              <p className="text-white/70 text-sm leading-relaxed">{current.narration}</p>
            </motion.div>
          </AnimatePresence>
        </div>
        <button onClick={toggleMute} className="p-2 text-white/30 hover:text-white/60 transition-all">
          {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>
      </div>

      {/* Next button */}
      <button
        onClick={handleNext}
        className="w-full py-3 rounded-xl bg-gradient-to-r from-mint to-holo text-background font-semibold text-sm hover:opacity-90 transition-all flex items-center justify-center gap-2"
      >
        {phase < PHASE_NARRATIONS.length - 1 ? "Next Stroke" : "Complete"}
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
}