import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, X, Target } from "lucide-react";
import { ENGINE_PARTS } from "@/lib/courseData";

export default function IdentificationChallenge({ setEngineConfig, clickedPart, onConsumeClick, onComplete }) {
  const [targetIndex, setTargetIndex] = useState(0);
  const [feedback, setFeedback] = useState(null);
  const [found, setFound] = useState(0);

  const target = ENGINE_PARTS[targetIndex];

  // Configure engine
  useEffect(() => {
    setEngineConfig({
      phase: 0,
      paused: true,
      interactive: true,
      exploded: false,
      showLabels: false,
      highlightedPart: null,
    });
  }, [setEngineConfig]);

  // Handle part clicks
  useEffect(() => {
    if (!clickedPart) return;
    if (clickedPart.partId === target.id) {
      setFeedback("correct");
      setFound(f => f + 1);
      setTimeout(() => {
        onConsumeClick();
        setFeedback(null);
        if (targetIndex < ENGINE_PARTS.length - 1) {
          setTargetIndex(i => i + 1);
        } else {
          onComplete();
        }
      }, 1200);
    } else {
      setFeedback("wrong");
      setTimeout(() => {
        onConsumeClick();
        setFeedback(null);
      }, 1000);
    }
  }, [clickedPart?.timestamp]);

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Target className="w-4 h-4 text-mint" />
          <span className="text-white/40 text-xs font-semibold uppercase tracking-wide">Find the part</span>
        </div>
        <span className="text-white/30 text-xs">{found}/{ENGINE_PARTS.length} found</span>
      </div>

      {/* Target part name */}
      <div className="text-center mb-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={targetIndex}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.3 }}
            className={`inline-block px-6 py-3 rounded-2xl ${
              feedback === "correct"
                ? "bg-mint/20 border border-mint/40"
                : feedback === "wrong"
                ? "bg-red-500/20 border border-red-500/40"
                : "glass border border-white/10"
            }`}
          >
            <p className="text-white font-bold text-lg">{target.name}</p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Feedback */}
      <div className="h-8 flex items-center justify-center">
        <AnimatePresence>
          {feedback === "correct" && (
            <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex items-center gap-1.5 text-mint text-sm font-medium">
              <Check className="w-4 h-4" /> Correct! That's the {target.name}.
            </motion.div>
          )}
          {feedback === "wrong" && (
            <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex items-center gap-1.5 text-red-400 text-sm font-medium">
              <X className="w-4 h-4" /> Not quite — that's a different part.
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Hint */}
      {feedback === null && (
        <p className="text-center text-white/30 text-xs">Tap the highlighted part on the engine diagram above.</p>
      )}
    </div>
  );
}