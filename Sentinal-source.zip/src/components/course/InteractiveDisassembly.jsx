import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronRight, Info } from "lucide-react";
import { ENGINE_PARTS } from "@/lib/courseData";

export default function InteractiveDisassembly({ setEngineConfig, clickedPart, onConsumeClick, onComplete }) {
  const [selectedPart, setSelectedPart] = useState(null);
  const [explored, setExplored] = useState(new Set());

  useEffect(() => {
    setEngineConfig({
      phase: null,
      paused: true,
      interactive: true,
      exploded: true,
      showLabels: true,
      highlightedPart: null,
    });
  }, [setEngineConfig]);

  useEffect(() => {
    if (!clickedPart) return;
    setSelectedPart(clickedPart.partId);
    setExplored(prev => new Set([...prev, clickedPart.partId]));
    onConsumeClick();
  }, [clickedPart?.timestamp]);

  const partInfo = ENGINE_PARTS.find(p => p.id === selectedPart);
  const allExplored = explored.size >= 5;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-white font-bold text-base">Interactive Disassembly</h3>
          <p className="text-white/40 text-xs mt-0.5">Tap any part to explore it</p>
        </div>
        <span className="text-white/30 text-xs">{explored.size}/{ENGINE_PARTS.length}</span>
      </div>

      {/* Selected part info */}
      <div className="min-h-[100px] mb-4">
        <AnimatePresence mode="wait">
          {partInfo ? (
            <motion.div
              key={selectedPart}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="glass rounded-xl p-4"
            >
              <div className="flex items-center gap-2 mb-1.5">
                <div className="w-2 h-2 rounded-full bg-mint" />
                <h4 className="text-mint font-semibold text-sm">{partInfo.name}</h4>
              </div>
              <p className="text-white/60 text-sm leading-relaxed">{partInfo.description}</p>
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="glass rounded-xl p-4 flex items-center gap-2"
            >
              <Info className="w-4 h-4 text-white/30" />
              <p className="text-white/30 text-sm">Select a part from the exploded diagram to learn about it.</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Part list */}
      <div className="flex flex-wrap gap-1.5 mb-4">
        {ENGINE_PARTS.map(part => (
          <div
            key={part.id}
            className={`px-2.5 py-1 rounded-full text-[10px] font-medium transition-all ${
              explored.has(part.id)
                ? "bg-mint/10 text-mint border border-mint/20"
                : "glass text-white/30"
            }`}
          >
            {part.name}
          </div>
        ))}
      </div>

      {/* Complete button */}
      <button
        onClick={onComplete}
        disabled={!allExplored}
        className="w-full py-3 rounded-xl bg-gradient-to-r from-mint to-holo text-background font-semibold text-sm hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-30 disabled:cursor-not-allowed"
      >
        {allExplored ? "Complete" : `Explore ${5 - explored.size} more parts`}
        {allExplored && <ChevronRight className="w-4 h-4" />}
      </button>
    </div>
  );
}