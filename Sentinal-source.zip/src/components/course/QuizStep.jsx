import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, X, ChevronRight, Award } from "lucide-react";
import { QUIZ_QUESTIONS } from "@/lib/courseData";

export default function QuizStep({ onComplete }) {
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [score, setScore] = useState(0);

  const question = QUIZ_QUESTIONS[currentQ];
  const isCorrect = selected === question.correctIndex;

  const handleAnswer = (index) => {
    if (showFeedback) return;
    setSelected(index);
    setShowFeedback(true);
    if (index === question.correctIndex) {
      setScore(s => s + 1);
    }
    setTimeout(() => {
      if (currentQ < QUIZ_QUESTIONS.length - 1) {
        setCurrentQ(q => q + 1);
        setSelected(null);
        setShowFeedback(false);
      } else {
        onComplete();
      }
    }, 2500);
  };

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Award className="w-4 h-4 text-mint" />
          <span className="text-white/40 text-xs font-semibold uppercase tracking-wide">Final Quiz</span>
        </div>
        <span className="text-white/30 text-xs">{currentQ + 1}/{QUIZ_QUESTIONS.length}</span>
      </div>

      {/* Progress dots */}
      <div className="flex gap-1.5 mb-4">
        {QUIZ_QUESTIONS.map((_, i) => (
          <div
            key={i}
            className="flex-1 h-1 rounded-full transition-all"
            style={{
              backgroundColor: i < currentQ ? "#2DD4BF" : i === currentQ ? "rgba(45,212,191,0.5)" : "rgba(255,255,255,0.08)",
            }}
          />
        ))}
      </div>

      {/* Question */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQ}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
        >
          <h3 className="text-white font-bold text-base mb-4 leading-snug">{question.question}</h3>

          {/* Options */}
          <div className="space-y-2">
            {question.options.map((option, i) => {
              const isSelected = selected === i;
              const isAnswerCorrect = i === question.correctIndex;
              const showCorrect = showFeedback && isAnswerCorrect;
              const showWrong = showFeedback && isSelected && !isAnswerCorrect;

              return (
                <button
                  key={i}
                  onClick={() => handleAnswer(i)}
                  disabled={showFeedback}
                  className={`w-full text-left px-4 py-3 rounded-xl text-sm font-medium transition-all border flex items-center justify-between ${
                    showCorrect
                      ? "bg-mint/15 border-mint/40 text-mint"
                      : showWrong
                      ? "bg-red-500/15 border-red-500/40 text-red-400"
                      : isSelected
                      ? "bg-white/10 border-white/20 text-white"
                      : "glass border-white/5 text-white/60 hover:border-white/15"
                  }`}
                >
                  <span>{option}</span>
                  {showCorrect && <Check className="w-4 h-4 flex-shrink-0" />}
                  {showWrong && <X className="w-4 h-4 flex-shrink-0" />}
                </button>
              );
            })}
          </div>

          {/* Explanation */}
          <AnimatePresence>
            {showFeedback && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`mt-4 p-3 rounded-xl text-sm ${
                  isCorrect ? "bg-mint/5 text-mint/80" : "bg-red-500/5 text-red-400/80"
                }`}
              >
                <p className="font-medium mb-1">{isCorrect ? "Correct!" : "Not quite."}</p>
                <p className="text-white/50 text-xs leading-relaxed">{question.explanation}</p>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </AnimatePresence>

      {/* Score */}
      {showFeedback && (
        <div className="mt-4 text-center">
          <p className="text-white/30 text-xs">Score: {score}/{QUIZ_QUESTIONS.length}</p>
        </div>
      )}
    </div>
  );
}