import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Timer, Check, X, Zap } from "lucide-react";
import { ENGINE_PARTS } from "@/lib/courseData";

const DURATION = 30;

export default function SpeedTest({ setEngineConfig, clickedPart, onConsumeClick, onComplete }) {
  const [timeLeft, setTimeLeft] = useState(DURATION);
  const [score, setScore] = useState(0);
  const [targetIndex, setTargetIndex] = useState(0);
  const [feedback, setFeedback] = useState(null);
  const finishedRef = useRef(false);

  const target = ENGINE_PARTS[targetIndex];

  useEffect(() => {
    setEngineConfig({
      phase: 2,
      paused: true,
      interactive: true,
      exploded: false,
      showLabels: false,
      highlightedPart: null,
    });
  }, [setEngineConfig]);

  // Timer
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) {
          clearInterval(timer);
          if (!finishedRef.current) {
            finishedRef.current = true;
            setTimeout(() => onComplete(), 500);
          }
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [onComplete]);

  // Handle clicks
  useEffect(() => {
    if (!clickedPart) return;
    if (clickedPart.partId === target.id) {
      setScore(s => s + 1);
      setFeedback("correct");
      setTargetIndex(i => (i + 1) % ENGINE_PARTS.length);
    } else {
      setFeedback("wrong");
    }
    onConsumeClick();
    const fbTimer = setTimeout(() => setFeedback(null), 400);
    return () => clearTimeout(fbTimer);
  }, [clickedPart?.timestamp]);

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-mint" />
          <span className="text-white/40 text-xs font-semibold uppercase tracking-wide">Speed Test</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 text-white/60 text-sm">
            <span className="text-mint font-bold text-lg">{score}</span>
            <span className="text-xs">correct</span>
          </div>
          <div className={`flex items-center gap-1 text-sm font-bold ${timeLeft <= 5 ? "text-red-400" : "text-white/60"}`}>
            <Timer className="w-4 h-4" />
            {timeLeft}s
          </div>
        </div>
      </div>

      {/* Timer bar */}
      <div className="h-1 rounded-full bg-white/5 overflow-hidden mb-4">
        <motion.div
          className="h-full rounded-full"
          style={{ backgroundColor: timeLeft <= 5 ? "#EF4444" : "#2DD4BF" }}
          animate={{ width: `${(timeLeft / DURATION) * 100}%` }}
          transition={{ duration: 1, ease: "linear" }}
        />
      </div>

      {/* Target */}
      <div className="text-center mb-2">
        <p className="text-white/30 text-xs mb-2">Tap the:</p>
        <AnimatePresence mode="wait">
          <motion.div
            key={targetIndex}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.2 }}
            className={`inline-block px-6 py-3 rounded-2xl ${
              feedback === "correct"
                ? "bg-mint/20 border border-mint/40"
                : feedback === "wrong"
                ? "bg-red-500/20 border border-red-500/40"
                : "glass border border-white/10"
            }`}
          >
            <p className="text-white font-bold text-lg">{target.name}</p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Feedback */}
      <div className="h-6 flex items-center justify-center">
        <AnimatePresence>
          {feedback === "correct" && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-1 text-mint text-sm">
              <Check className="w-3.5 h-3.5" /> Got it!
            </motion.div>
          )}
          {feedback === "wrong" && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-1 text-red-400 text-sm">
              <X className="w-3.5 h-3.5" /> Nope!
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}