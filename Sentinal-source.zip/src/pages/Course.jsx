import React, { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Check, ChevronRight, X, Award } from "lucide-react";
import { getCourseById } from "@/lib/courseData";
import { useAuth } from "@/lib/AuthContext";
import { base44 } from "@/api/base44Client";
import { getCourseProgress, saveCourseProgress, updateUserXP, updateStreak } from "@/lib/userHelpers";
import EngineVisualization from "@/components/EngineVisualization";
import AnimatedExplanation from "@/components/course/AnimatedExplanation";
import IdentificationChallenge from "@/components/course/IdentificationChallenge";
import InteractiveDisassembly from "@/components/course/InteractiveDisassembly";
import SpeedTest from "@/components/course/SpeedTest";
import QuizStep from "@/components/course/QuizStep";

export default function Course() {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const course = getCourseById(courseId);

  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState([]);
  const [stepXP, setStepXP] = useState(0);
  const [courseFinished, setCourseFinished] = useState(false);
  const [loading, setLoading] = useState(true);

  // Engine config state — controlled by step components
  const [engineConfig, setEngineConfig] = useState({
    phase: null, paused: false, interactive: false, exploded: false, showLabels: false,
  });
  const [clickedPart, setClickedPart] = useState(null);
  const [highlightedPart, setHighlightedPart] = useState(null);

  // Load progress
  useEffect(() => {
    if (!courseId) return;
    (async () => {
      try {
        const progress = await getCourseProgress(courseId);
        if (progress) {
          setCurrentStep(progress.current_step || 0);
          setCompletedSteps(progress.completed_steps || []);
          setStepXP(progress.xp_earned || 0);
          if (progress.completed) setCourseFinished(true);
        }
      } catch { /* empty progress is fine */ }
      setLoading(false);
    })();
  }, [courseId]);

  const handlePartClick = useCallback((partId) => {
    setClickedPart({ partId, timestamp: Date.now() });
    setHighlightedPart(partId);
  }, []);

  const handleStepComplete = useCallback(async () => {
    if (!course) return;
    const step = course.steps[currentStep];
    const newCompleted = [...new Set([...completedSteps, currentStep])];
    setCompletedSteps(newCompleted);

    // Award XP
    try {
      await updateUserXP(step.xp);
      await updateStreak();
    } catch { /* non-critical */ }

    const totalXP = stepXP + step.xp;
    setStepXP(totalXP);

    const isLastStep = currentStep >= course.steps.length - 1;

    if (isLastStep) {
      // Course complete
      try {
        await saveCourseProgress(courseId, {
          current_step: currentStep,
          completed_steps: newCompleted,
          xp_earned: totalXP,
          completed: true,
        });
      } catch { /* non-critical */ }
      setCourseFinished(true);
    } else {
      // Save progress and advance
      try {
        await saveCourseProgress(courseId, {
          current_step: currentStep + 1,
          completed_steps: newCompleted,
          xp_earned: totalXP,
          completed: false,
        });
      } catch { /* non-critical */ }
      setCurrentStep(s => s + 1);
      setHighlightedPart(null);
      setClickedPart(null);
    }
  }, [course, currentStep, completedSteps, stepXP, courseId]);

  if (!course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-white/40">Course not found.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-white/10 border-t-mint rounded-full animate-spin" />
      </div>
    );
  }

  if (courseFinished) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
        <div className="w-20 h-20 rounded-full bg-gradient-to-br from-mint to-holo flex items-center justify-center mb-6 animate-orb">
          <Award className="w-10 h-10 text-background" />
        </div>
        <h1 className="text-2xl font-bold text-white mb-2 font-heading">Course Complete!</h1>
        <p className="text-white/40 text-sm mb-1">You earned {course.xpTotal} XP</p>
        <p className="text-white/60 text-sm mb-8">You've mastered The Four-Stroke Engine.</p>
        <button
          onClick={() => navigate("/learn")}
          className="px-8 py-3 rounded-full bg-gradient-to-r from-mint to-holo text-background font-semibold text-sm hover:opacity-90 transition-all"
        >
          Back to Learn
        </button>
      </div>
    );
  }

  const step = course.steps[currentStep];
  const stepProps = {
    setEngineConfig,
    clickedPart,
    onConsumeClick: () => { setClickedPart(null); setHighlightedPart(null); },
    onComplete: handleStepComplete,
    setHighlightedPart,
  };

  return (
    <div className="min-h-screen px-4 pt-6 pb-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <button onClick={() => navigate("/learn")} className="p-2 -ml-2 text-white/40 hover:text-white transition-all">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1 mx-3">
          <div className="flex items-center gap-1">
            {course.steps.map((_, i) => (
              <div
                key={i}
                className="flex-1 h-1 rounded-full transition-all"
                style={{
                  backgroundColor: i <= currentStep ? "#2DD4BF" : "rgba(255,255,255,0.08)",
                }}
              />
            ))}
          </div>
          <p className="text-white/30 text-[10px] mt-1 text-center font-medium uppercase tracking-wide">
            Step {currentStep + 1} of {course.steps.length} · {step.title}
          </p>
        </div>
        <div className="w-9" />
      </div>

      {/* Engine Visualization */}
      <div className="glass-card rounded-3xl p-4 mb-4">
        <EngineVisualization
          phase={engineConfig.phase}
          paused={engineConfig.paused}
          interactive={engineConfig.interactive}
          exploded={engineConfig.exploded}
          showLabels={engineConfig.showLabels}
          highlightedPart={highlightedPart}
          onPartClick={handlePartClick}
        />
      </div>

      {/* Step Content */}
      <div className="glass-strong rounded-3xl p-5">
        {step.type === "animated_explanation" && <AnimatedExplanation {...stepProps} />}
        {step.type === "identification" && <IdentificationChallenge {...stepProps} />}
        {step.type === "disassembly" && <InteractiveDisassembly {...stepProps} />}
        {step.type === "speed_test" && <SpeedTest {...stepProps} />}
        {step.type === "quiz" && <QuizStep {...stepProps} />}
      </div>
    </div>
  );
}