import React from "react";
import { Link } from "react-router-dom";
import { Flame, Zap, Lock, ArrowRight, GraduationCap, Sparkles, ScanLine, ClipboardList, PenTool, PlayCircle } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { COURSES } from "@/lib/courseData";

export default function Home() {
  const { user } = useAuth();

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const displayName = user?.username || user?.full_name || user?.email?.split("@")[0] || "Learner";

  const enrolledCourse = COURSES.find(c => !c.locked);

  const handleOpenSen = () => {
    window.dispatchEvent(new CustomEvent("open-sen-chat"));
  };

  const tiles = [
    { icon: GraduationCap, label: "Learn", desc: "Browse courses", to: "/learn", locked: false },
    { icon: Sparkles, label: "Ask Sen", desc: "AI tutor", onClick: handleOpenSen, locked: false },
    { icon: PlayCircle, label: "Tutorial", desc: "Replay intro", to: "/tutorial", locked: false },
    { icon: ScanLine, label: "Scan", desc: "Coming soon", locked: true },
    { icon: ClipboardList, label: "Dispatch", desc: "Coming soon", locked: true },
    { icon: PenTool, label: "Create", desc: "Coming soon", locked: true },
  ];

  return (
    <div className="min-h-screen px-4 pt-8 pb-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-full overflow-hidden glass border border-white/10 flex items-center justify-center">
            {user?.avatar_url ? (
              <img src={user.avatar_url} alt="avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="text-mint font-bold text-sm">{displayName[0]?.toUpperCase()}</span>
            )}
          </div>
          <div>
            <p className="text-white/40 text-xs">{greeting},</p>
            <h1 className="text-white font-bold text-lg leading-tight">{displayName}</h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="glass rounded-full px-3 py-1.5 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-mint" />
            <span className="text-white font-semibold text-sm">{user?.xp || 0}</span>
            <span className="text-white/40 text-xs">XP</span>
          </div>
          <div className="glass rounded-full px-3 py-1.5 flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-orange-400" />
            <span className="text-white font-semibold text-sm">{user?.streak || 0}</span>
          </div>
        </div>
      </div>

      {/* Continue Learning Hero */}
      {enrolledCourse && (
        <Link to={`/course/${enrolledCourse.id}`} className="block mb-6 group">
          <div className="relative glass-card rounded-3xl p-6 overflow-hidden">
            <div className="absolute -right-8 -top-8 w-40 h-40 rounded-full bg-mint/10 blur-3xl group-hover:bg-mint/15 transition-all" />
            <div className="relative z-10 flex items-center gap-5">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-mint/20 to-holo/10 border border-mint/20 flex items-center justify-center flex-shrink-0">
                <GraduationCap className="w-8 h-8 text-mint" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-mint text-xs font-semibold mb-1">CONTINUE LEARNING</p>
                <h2 className="text-white font-bold text-lg leading-tight mb-1">{enrolledCourse.title}</h2>
                <p className="text-white/40 text-xs">{enrolledCourse.description}</p>
              </div>
              <ArrowRight className="w-5 h-5 text-white/30 group-hover:text-mint group-hover:translate-x-1 transition-all flex-shrink-0" />
            </div>
          </div>
        </Link>
      )}

      {/* Tiles Grid */}
      <div className="grid grid-cols-2 gap-3 mb-8">
        {tiles.map((tile, i) => {
          const Tile = tile.locked ? "div" : tile.to ? Link : "button";
          const tileProps = tile.to ? { to: tile.to } : tile.onClick ? { onClick: tile.onClick } : {};
          const Icon = tile.icon;
          return (
            <Tile
              key={i}
              {...tileProps}
              className={`glass-card rounded-2xl p-4 flex flex-col items-start gap-3 transition-all ${
                tile.locked ? "opacity-40 cursor-not-allowed" : "hover:border-mint/20 cursor-pointer"
              }`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                tile.locked ? "bg-white/5" : "bg-mint/10 border border-mint/20"
              }`}>
                {tile.locked ? <Lock className="w-4 h-4 text-white/30" /> : <Icon className="w-5 h-5 text-mint" />}
              </div>
              <div>
                <p className="text-white font-semibold text-sm">{tile.label}</p>
                <p className="text-white/30 text-xs">{tile.desc}</p>
              </div>
            </Tile>
          );
        })}
      </div>

      {/* Bottom tagline */}
      <div className="text-center mt-8">
        <p className="text-white/20 text-xs font-medium tracking-widest uppercase">Learn it. Scan it. Build it.</p>
      </div>
    </div>
  );
}