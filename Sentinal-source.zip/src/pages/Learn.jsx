import React, { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { Search, Flame, Zap, Lock } from "lucide-react";
import { CATEGORIES, CATEGORY_COLORS, COURSES } from "@/lib/courseData";
import { useAuth } from "@/lib/AuthContext";
import CourseCard from "@/components/CourseCard";

export default function Learn() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const filtered = useMemo(() => {
    return COURSES.filter(course => {
      const matchesCategory = activeCategory === "All" || course.category === activeCategory;
      const matchesSearch = !search ||
        course.title.toLowerCase().includes(search.toLowerCase()) ||
        course.description.toLowerCase().includes(search.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [search, activeCategory]);

  return (
    <div className="min-h-screen px-4 pt-8 pb-4">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white font-heading mb-1">Learn</h1>
        <p className="text-white/40 text-sm">Master automotive engineering, one course at a time.</p>
      </div>

      {/* XP + Streak */}
      <div className="flex items-center gap-2 mb-6">
        <div className="glass rounded-xl px-3 py-2 flex items-center gap-2 flex-1">
          <Zap className="w-4 h-4 text-mint" />
          <span className="text-white font-bold">{user?.xp || 0}</span>
          <span className="text-white/40 text-xs">XP earned</span>
        </div>
        <div className="glass rounded-xl px-3 py-2 flex items-center gap-2 flex-1">
          <Flame className="w-4 h-4 text-orange-400" />
          <span className="text-white font-bold">{user?.streak || 0}</span>
          <span className="text-white/40 text-xs">day streak</span>
        </div>
      </div>

      {/* Search */}
      <div className="relative mb-5">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search courses..."
          className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder:text-white/20 outline-none focus:border-mint/30 transition-all"
        />
      </div>

      {/* Category chips */}
      <div className="flex gap-2 overflow-x-auto scrollbar-none pb-2 mb-6 -mx-4 px-4">
        <button
          onClick={() => setActiveCategory("All")}
          className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all flex-shrink-0 ${
            activeCategory === "All"
              ? "bg-mint text-background"
              : "glass text-white/50 hover:text-white/80"
          }`}
        >
          All
        </button>
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all flex-shrink-0 flex items-center gap-1.5 ${
              activeCategory === cat
                ? "text-background"
                : "glass text-white/50 hover:text-white/80"
            }`}
            style={activeCategory === cat ? { backgroundColor: CATEGORY_COLORS[cat] } : {}}
          >
            <div className={`w-2 h-2 rounded-full ${activeCategory === cat ? "bg-background/30" : ""}`} style={{ backgroundColor: activeCategory === cat ? "rgba(0,0,0,0.3)" : CATEGORY_COLORS[cat] }} />
            {cat}
          </button>
        ))}
      </div>

      {/* Timeline */}
      <div className="relative">
        {/* Progress line */}
        <div className="absolute left-[27px] top-0 bottom-0 w-px bg-gradient-to-b from-mint/30 via-white/10 to-transparent" />

        <div className="space-y-4">
          {filtered.map((course, i) => (
            <CourseCard key={course.id} course={course} index={i} />
          ))}
        </div>
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12">
          <p className="text-white/30 text-sm">No courses found. Try a different search.</p>
        </div>
      )}
    </div>
  );
}