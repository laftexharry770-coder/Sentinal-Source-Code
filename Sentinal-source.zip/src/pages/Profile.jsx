import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Camera, LogOut, Flame, Zap, Check, ChevronRight, BookOpen, Sparkles, Eye, EyeOff, Trash2, AlertTriangle, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { COURSES } from "@/lib/courseData";
import { getAllCourseProgress } from "@/lib/userHelpers";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
} from "@/components/ui/alert-dialog";

export default function Profile() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [editing, setEditing] = useState(false);
  const [username, setUsername] = useState(user?.username || "");
  const [gender, setGender] = useState(user?.gender || "");
  const [age, setAge] = useState(user?.age || "");
  const [avatarUrl, setAvatarUrl] = useState(user?.avatar_url || "");
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState([]);
  const [saving, setSaving] = useState(false);
  const [geminiKey, setGeminiKey] = useState(user?.gemini_api_key || "");
  const [showKey, setShowKey] = useState(false);
  const [keySaving, setKeySaving] = useState(false);
  const [keySaved, setKeySaved] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteConfirmStep, setDeleteConfirmStep] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    loadProgress();
  }, []);

  const loadProgress = async () => {
    try {
      const p = await getAllCourseProgress();
      setProgress(p);
    } catch { /* empty is fine */ }
  };

  const handleAvatarChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setAvatarUrl(file_url);
    } catch { /* ignore */ }
    setUploading(false);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await base44.auth.updateMe({
        username: username.trim(),
        gender: gender || "prefer_not_to_say",
        age: age ? parseInt(age) : null,
        avatar_url: avatarUrl,
      });
      setEditing(false);
    } catch { /* ignore */ }
    setSaving(false);
  };

  const handleLogout = () => {
    logout();
  };

  const handleDeleteAccount = async () => {
    if (deleteConfirmStep === 0) {
      setDeleteConfirmStep(1);
      return;
    }
    setDeleting(true);
    try {
      await base44.auth.updateMe({ account_deleted: true });
      logout();
    } catch {
      /* if update fails, still log out */
      logout();
    }
    setDeleting(false);
  };

  const handleDeleteDialogChange = (open) => {
    setDeleteDialogOpen(open);
    if (!open) {
      setDeleteConfirmStep(0);
    }
  };

  const displayName = user?.username || user?.full_name || "User";
  const prefs = user?.preferences || {};
  const enrolledCourse = COURSES.find(c => !c.locked);
  const courseProgress = progress.find(p => p.course_id === enrolledCourse?.id);

  return (
    <div className="min-h-screen px-4 pt-8 pb-4">
      {/* Header */}
      <div className="flex flex-col items-center mb-8">
        <div className="relative mb-4">
          <div className="w-24 h-24 rounded-full overflow-hidden glass border-2 border-white/10 flex items-center justify-center">
            {avatarUrl ? (
              <img src={avatarUrl} alt="avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="text-mint font-bold text-2xl">{displayName[0]?.toUpperCase()}</span>
            )}
          </div>
          {editing && (
            <button
              onClick={() => document.getElementById("avatar-input")?.click()}
              className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-mint flex items-center justify-center border-2 border-background"
            >
              {uploading ? <div className="w-3 h-3 border-2 border-background/30 border-t-background rounded-full animate-spin" /> : <Camera className="w-4 h-4 text-background" />}
            </button>
          )}
          <input id="avatar-input" type="file" accept="image/*" onChange={handleAvatarChange} className="hidden" />
        </div>

        {!editing ? (
          <>
            <h1 className="text-xl font-bold text-white">{displayName}</h1>
            <p className="text-white/40 text-sm">{user?.email}</p>
            <button onClick={() => setEditing(true)} className="mt-3 text-mint text-sm font-medium hover:underline">
              Edit profile
            </button>
          </>
        ) : (
          <div className="w-full max-w-xs space-y-3">
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/20 outline-none focus:border-mint/30 text-center"
            />
            <div className="grid grid-cols-2 gap-2">
              <Select value={gender || undefined} onValueChange={setGender}>
                <SelectTrigger className="bg-white/5 border-white/10 rounded-xl px-3 py-2.5 text-sm text-white h-auto">
                  <SelectValue placeholder="Gender" />
                </SelectTrigger>
                <SelectContent className="bg-popover border-white/10">
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                  <SelectItem value="prefer_not_to_say">N/A</SelectItem>
                </SelectContent>
              </Select>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="Age"
                className="bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder:text-white/20 outline-none focus:border-mint/30"
              />
            </div>
            <div className="flex gap-2">
              <button onClick={() => setEditing(false)} className="flex-1 py-2.5 rounded-xl glass text-white/60 text-sm font-medium">
                Cancel
              </button>
              <button onClick={handleSave} disabled={saving} className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-mint to-holo text-background text-sm font-semibold disabled:opacity-50">
                {saving ? "Saving..." : "Save"}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="glass-card rounded-2xl p-4 text-center">
          <Zap className="w-5 h-5 text-mint mx-auto mb-1" />
          <p className="text-white font-bold text-2xl">{user?.xp || 0}</p>
          <p className="text-white/30 text-xs">Total XP</p>
        </div>
        <div className="glass-card rounded-2xl p-4 text-center">
          <Flame className="w-5 h-5 text-orange-400 mx-auto mb-1" />
          <p className="text-white font-bold text-2xl">{user?.streak || 0}</p>
          <p className="text-white/30 text-xs">Day Streak</p>
        </div>
      </div>

      {/* Preferences */}
      {prefs.interests && prefs.interests.length > 0 && (
        <div className="mb-6">
          <p className="text-white/40 text-xs font-semibold mb-2 uppercase tracking-wide">Interests</p>
          <div className="flex flex-wrap gap-2">
            {prefs.interests.map(interest => (
              <span key={interest} className="px-3 py-1 rounded-full glass text-white/60 text-xs">{interest}</span>
            ))}
          </div>
        </div>
      )}

      {/* Course Progress */}
      <div className="mb-6">
        <p className="text-white/40 text-xs font-semibold mb-2 uppercase tracking-wide">Course Progress</p>
        <div className="space-y-2">
          {COURSES.filter(c => !c.locked).map(course => {
            const p = progress.find(pr => pr.course_id === course.id);
            const completed = p?.completed_steps?.length || 0;
            const total = course.steps.length;
            const pct = total > 0 ? (completed / total) * 100 : 0;
            return (
              <div key={course.id} className="glass-card rounded-xl p-3">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-white text-sm font-medium">{course.title}</span>
                  {p?.completed ? (
                    <span className="text-mint text-xs flex items-center gap-1"><Check className="w-3 h-3" /> Complete</span>
                  ) : (
                    <span className="text-white/30 text-xs">{completed}/{total} steps</span>
                  )}
                </div>
                <div className="h-1 rounded-full bg-white/5 overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-mint to-holo rounded-full transition-all" style={{ width: `${pct}%` }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sen AI settings */}
      <div className="mb-6">
        <p className="text-white/40 text-xs font-semibold mb-2 uppercase tracking-wide">Sen AI</p>
        <div className="glass-card rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-4 h-4 text-mint" />
            <span className="text-white text-sm font-medium">Gemini API key</span>
            <span className={`ml-auto text-[10px] px-2 py-0.5 rounded-full ${user?.gemini_api_key ? "bg-mint/15 text-mint" : "bg-white/5 text-white/30"}`}>
              {user?.gemini_api_key ? "Active" : "Not set"}
            </span>
          </div>
          <p className="text-white/30 text-xs mb-3">
            Optional. Paste your own Google Gemini API key and Sen will use it for answers. Without one, Sen uses the built-in AI. Your key is stored only on your account.
          </p>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <input
                type={showKey ? "text" : "password"}
                value={geminiKey}
                onChange={(e) => { setGeminiKey(e.target.value); setKeySaved(false); }}
                placeholder="Paste Gemini API key"
                autoComplete="off"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 pr-10 text-sm text-white placeholder:text-white/20 outline-none focus:border-mint/30"
              />
              <button
                type="button"
                onClick={() => setShowKey(s => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60"
                aria-label="Toggle key visibility"
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <button
              onClick={async () => {
                setKeySaving(true);
                try {
                  await base44.auth.updateMe({ gemini_api_key: geminiKey.trim() });
                  setKeySaved(true);
                } catch { /* ignore */ }
                setKeySaving(false);
              }}
              disabled={keySaving}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-mint to-holo text-background text-sm font-semibold disabled:opacity-50 flex-shrink-0"
            >
              {keySaving ? "..." : keySaved ? "Saved" : "Save"}
            </button>
          </div>
        </div>
      </div>

      {/* Logout */}
      <button
        onClick={handleLogout}
        className="w-full py-3 rounded-xl glass text-red-400 text-sm font-medium hover:bg-red-500/10 transition-all flex items-center justify-center gap-2"
      >
        <LogOut className="w-4 h-4" />
        Log out
      </button>

      {/* Delete Account */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={handleDeleteDialogChange}>
        <AlertDialogTrigger asChild>
          <button
            className="w-full py-3 mt-2 rounded-xl glass text-red-400/70 text-sm font-medium hover:bg-red-500/10 transition-all flex items-center justify-center gap-2"
          >
            <Trash2 className="w-4 h-4" />
            Delete account
          </button>
        </AlertDialogTrigger>
        <AlertDialogContent className="glass-strong border-white/10 max-w-sm">
          <AlertDialogHeader>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-full bg-red-500/15 flex items-center justify-center">
                <AlertTriangle className="w-4 h-4 text-red-400" />
              </div>
              <AlertDialogTitle className="text-white text-base font-bold">
                {deleteConfirmStep === 0 ? "Delete account?" : "Are you absolutely sure?"}
              </AlertDialogTitle>
            </div>
            <AlertDialogDescription className="text-white/50 text-sm leading-relaxed">
              {deleteConfirmStep === 0
                ? "This will permanently remove your account, profile data, XP, streak, and chat history. This action cannot be undone."
                : "This is your final warning. Once you confirm, your account and all associated data will be permanently deleted. You will be logged out immediately."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-row gap-2">
            <AlertDialogCancel className="flex-1 mt-0 sm:mt-0 bg-white/5 border-white/10 text-white/60 hover:bg-white/10 hover:text-white">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteAccount}
              className="flex-1 bg-red-500 text-white hover:bg-red-600 border-0"
            >
              {deleting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : deleteConfirmStep === 0 ? (
                "Continue"
              ) : (
                "Delete forever"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}