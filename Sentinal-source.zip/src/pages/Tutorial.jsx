import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { ChevronRight, SkipForward, Sparkles, Check } from "lucide-react";
import { CATEGORIES } from "@/lib/courseData";
import { useAuth } from "@/lib/AuthContext";

const STEPS = [
  {
    title: "Meet Sen",
    body: "I'm Sen — your AI mechanics teacher. I'll be with you every step of the way. Ask me anything, anytime. I'm here to help you learn.",
  },
  {
    title: "Learn the Craft",
    body: "Browse courses on engines, fuel systems, brakes, EV tech and more. Interactive lessons, real diagrams, and hands-on challenges.",
  },
  {
    title: "Build Your Skills",
    body: "Earn XP, keep your daily streak alive, and track your progress across every course. Master one topic at a time.",
  },
];

export default function Tutorial() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [step, setStep] = useState(0);
  const [preferences, setPreferences] = useState({
    interests: [],
    experience_level: "beginner",
    learning_style: "visual",
  });

  // Redirect if tutorial already completed
  useEffect(() => {
    if (user?.tutorial_completed) {
      navigate("/");
    }
  }, [user]);

  const isPrefsStep = step === STEPS.length;

  const handleComplete = async () => {
    try {
      await base44.auth.updateMe({
        tutorial_completed: true,
        preferences,
      });
    } catch {
      // non-critical
    }
    navigate("/");
  };

  const toggleInterest = (cat) => {
    setPreferences(prev => ({
      ...prev,
      interests: prev.interests.includes(cat)
        ? prev.interests.filter(c => c !== cat)
        : [...prev.interests, cat],
    }));
  };

  return (
    <div className="min-h-screen bg-background bg-mesh flex flex-col items-center justify-center px-6 relative overflow-hidden">
      {/* Ambient orbs */}
      <div className="absolute top-20 left-10 w-32 h-32 rounded-full bg-mint/10 blur-3xl animate-float" />
      <div className="absolute bottom-20 right-10 w-48 h-48 rounded-full bg-holo/8 blur-3xl animate-float" style={{ animationDelay: '1.5s' }} />

      {/* Skip button */}
      <button
        onClick={handleComplete}
        className="absolute top-6 right-6 flex items-center gap-1 text-white/30 hover:text-white/60 text-sm transition-all z-20"
      >
        Skip <SkipForward className="w-3.5 h-3.5" />
      </button>

      {/* Progress dots */}
      <div className="flex gap-2 mb-12 z-10">
        {[...STEPS, null].map((_, i) => (
          <div
            key={i}
            className="h-1.5 rounded-full transition-all duration-300"
            style={{
              width: i === step ? 24 : 8,
              backgroundColor: i === step ? "#2DD4BF" : "rgba(255,255,255,0.15)",
            }}
          />
        ))}
      </div>

      {/* Sen Orb */}
      <div className="relative mb-8 z-10">
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", duration: 0.8 }}
          className="relative"
        >
          <div className="w-28 h-28 rounded-full bg-gradient-to-br from-mint to-holo animate-orb flex items-center justify-center">
            <Sparkles className="w-12 h-12 text-background" />
          </div>
          <div className="absolute inset-0 w-28 h-28 rounded-full border border-mint/20 animate-spin-slow" />
          <div className="absolute -inset-4 w-36 h-36 rounded-full border border-holo/10 animate-spin-slow" style={{ animationDuration: '12s' }} />
        </motion.div>
      </div>

      {/* Content */}
      <div className="max-w-md w-full z-10">
        <AnimatePresence mode="wait">
          {!isPrefsStep ? (
            <motion.div
              key={step}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="text-center"
            >
              <h2 className="text-3xl font-bold text-white mb-3 font-heading">{STEPS[step].title}</h2>
              <p className="text-white/50 text-base leading-relaxed">{STEPS[step].body}</p>
            </motion.div>
          ) : (
            <motion.div
              key="prefs"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-5"
            >
              <div className="text-center mb-2">
                <h2 className="text-2xl font-bold text-white font-heading">Personalize your journey</h2>
                <p className="text-white/40 text-sm mt-1">Tell Sen what you're into</p>
              </div>

              {/* Interests */}
              <div>
                <p className="text-white/60 text-xs font-semibold mb-2 uppercase tracking-wide">Interests</p>
                <div className="flex flex-wrap gap-2">
                  {CATEGORIES.map(cat => (
                    <button
                      key={cat}
                      onClick={() => toggleInterest(cat)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                        preferences.interests.includes(cat)
                          ? "bg-mint text-background"
                          : "glass text-white/50 hover:text-white/80"
                      }`}
                    >
                      {preferences.interests.includes(cat) && <Check className="w-3 h-3 inline mr-1" />}
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Experience */}
              <div>
                <p className="text-white/60 text-xs font-semibold mb-2 uppercase tracking-wide">Experience Level</p>
                <div className="grid grid-cols-3 gap-2">
                  {["beginner", "intermediate", "advanced"].map(level => (
                    <button
                      key={level}
                      onClick={() => setPreferences(prev => ({ ...prev, experience_level: level }))}
                      className={`py-2.5 rounded-xl text-sm font-medium capitalize transition-all ${
                        preferences.experience_level === level
                          ? "bg-mint/15 text-mint border border-mint/30"
                          : "glass text-white/40 border border-white/5"
                      }`}
                    >
                      {level}
                    </button>
                  ))}
                </div>
              </div>

              {/* Learning Style */}
              <div>
                <p className="text-white/60 text-xs font-semibold mb-2 uppercase tracking-wide">Learning Style</p>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { val: "visual", label: "Visual" },
                    { val: "hands_on", label: "Hands-on" },
                    { val: "reading", label: "Reading" },
                  ].map(style => (
                    <button
                      key={style.val}
                      onClick={() => setPreferences(prev => ({ ...prev, learning_style: style.val }))}
                      className={`py-2.5 rounded-xl text-sm font-medium transition-all ${
                        preferences.learning_style === style.val
                          ? "bg-mint/15 text-mint border border-mint/30"
                          : "glass text-white/40 border border-white/5"
                      }`}
                    >
                      {style.label}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Next button */}
      <button
        onClick={() => {
          if (isPrefsStep) handleComplete();
          else setStep(s => s + 1);
        }}
        className="mt-10 z-10 flex items-center gap-2 px-8 py-3 rounded-full bg-gradient-to-r from-mint to-holo text-background font-semibold text-sm hover:opacity-90 transition-all"
      >
        {isPrefsStep ? "Start Learning" : "Continue"}
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
}